<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;
use App\Mail\NotificationMail;

class SendEmailNotification implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $emailData;

    /**
     * Create a new job instance.
     *
     * @param array $emailData
     */
    public function __construct(array $emailData)
    {
        $this->emailData = $emailData;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    //Again to retry the faild jobs
    public function backoff()
    {
        return [10, 30, 60, 120]; // Retry after 10s, 30s, 60s, and 120s
    }
    public function handle()
    {
        Mail::to($this->emailData['recipient'])->send(new NotificationMail($this->emailData));
    }
    public function failed(\Exception $exception)
    {
        // Logic to handle failure
        // For example, re-dispatch the job
        ExampleJob::dispatch()->delay(now()->addSeconds(60));
    }
}
