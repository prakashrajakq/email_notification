<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Jobs\SendEmailNotification;
use Illuminate\Support\Facades\Validator;
class emailController extends Controller
{
    public $emailData=[];
    public function sendEmail(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email',
            'message' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }

        $emailData = [
            'recipient' => $request->email,
            'subject' => 'Email Notification',
            'name' => 'Hello '.$request->name,
            'message' => $request->message,
        ];

        // Dispatch the job
        SendEmailNotification::dispatch($emailData);

       // return response()->json(['status' => 'Email sent to the queue!']);
       return redirect()->back()->withSuccess('
       Successfully added the Email Notification to the queue!');
    }
}
