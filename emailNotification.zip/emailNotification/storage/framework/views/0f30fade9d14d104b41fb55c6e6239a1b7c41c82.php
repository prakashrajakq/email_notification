<html>
    <body>
<p><?php echo e($emailData['name']); ?>,</p>
<p>Your Notification Email's requested data is as follows:</p>
<table border='1'>
    <tr><td>Name</td><td><?php echo e($emailData['name']); ?></td></tr>
    <tr><td>Email Address</td><td><?php echo e($emailData['recipient']); ?></td></tr>
    <tr><td>Message</td><td><?php echo e($emailData['message']); ?></td></tr>
</table>
</body>
</html>
<?php /**PATH /var/www/laravel/emailNotification/resources/views/emails/notification.blade.php ENDPATH**/ ?>