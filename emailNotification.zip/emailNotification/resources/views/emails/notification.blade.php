<html>
    <body>
<p>{{ $emailData['name'] }},</p>
<p>Your Notification Email's requested data is as follows:</p>
<table border='1'>
    <tr><td>Name</td><td>{{ $emailData['name'] }}</td></tr>
    <tr><td>Email Address</td><td>{{ $emailData['recipient'] }}</td></tr>
    <tr><td>Message</td><td>{{ $emailData['message'] }}</td></tr>
</table>
</body>
</html>
